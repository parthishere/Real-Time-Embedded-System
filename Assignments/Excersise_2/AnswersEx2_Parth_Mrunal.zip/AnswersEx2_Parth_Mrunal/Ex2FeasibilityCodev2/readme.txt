These examples are from the RTECS textbook, p. 84 - p. 89
Can be compiled with any C compiler and run in most any environment, but the examples were created and tested on Linux.

The idea is to add to these examples and compare them to Cheddar, to your hand analysis of scenarios, and to consider
different methods to implement an exact feasibility analysis and test for fixed priority rate monotonic policy.